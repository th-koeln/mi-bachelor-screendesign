# Irene Au

## Job/ Occupation
Design Partner at Khosla Ventures at The Interaction Design Foundation

## Location
San Francisco, United States

## Quote
Good design is like a refrigerator—when it works, no one notices, but when it doesn’t, it sure stinks.

## Dig deeper

Irene is the former head of UX and Design at Google. Currently, she is an operating partner at Khosla Ventures, where she works with portfolio companies to make their design great. She is dedicated to raising the strategic value of design and user research through better methods, practices, processes, leadership and quality. Irene does this by building high performing teams, establishing design practices, mentoring and growing the next generation of great designers and directing the design of interfaces and experiences. She drives strategic discussions at the highest levels of companies, focusing first on user needs to inspire product innovation.



