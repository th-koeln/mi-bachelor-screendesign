# Neville Brody

## Job/ Occupation
Grafikdesigner, Typograf und Art Director.

## Location
London, United Kingdom

## Quote
Digital design is like painting, except the paint never dries.

## Dig deeper

Neville Brody ist vermutlich der bekannteste Grafiker seiner Generation, Er studierte Grafikdesign am London College of Printing und wurde in den frühen 1980er Jahren durch seine Gestaltung von Plattencovern und sein Engagement für die unabhängige britische Musikszene bekannt.

Als Art Director bei Fetish begann er mit den Anfängen einer neuen, aus einem Mix aus optischen und architektonischen Elementen bestehenden visuellen Sprache zu experimentieren. Seine Ideen realisierte er später u.a. im wegweisend innovativen Styling von The Face Magazine (1981 bis 1986). Es war dann auch seine Arbeit für Zeitschriften, die ihn endgültig als einen der weltweit führenden Grafikdesigner fest etablierte. Seine künstlerischen Projekte für The Face stellten eine revolutionär neue Herangehensweise von Designern und Lesern an das Medium dar.
