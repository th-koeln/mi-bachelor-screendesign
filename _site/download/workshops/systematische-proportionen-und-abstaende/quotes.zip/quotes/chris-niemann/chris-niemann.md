# Christoph Niemann

## Job/ Occupation
Illustrator

## Location
Berlin, Germany

## Quote
Get rid of everything that is not essential to making a point.

## Dig deeper

Niemann ist in Ludwigsburg aufgewachsen. Er studierte an der Staatlichen Akademie der Bildenden Künste Stuttgart. Im Jahr 1997 zog Niemann nach New York City. Elf Jahre später kehrte er mit Lisa Zeitz und drei Söhnen nach Deutschland zurück und lebt seither in Berlin.

Seine Arbeiten erschienen unter anderem auf den Titelseiten von The New Yorker, Atlantic Monthly, The New York Times Magazine und American Illustration. Seit 2008 schreibt und illustriert Niemann den Blog der New York Times Abstract City, der seit 2011 vom New York Times Magazine unter dem Titel Abstract Sunday verwaltet wird.

2012 entwarf er für die Deutsche Post eine Briefmarke (MI-Nr. 2932); in diesem Jahr erhielt er auch den Sondermann-Preis für Komische Kunst. Sein Bilderbuch Der Kartoffelkönig wurde 2014 für den Deutschen Jugendliteraturpreis in der Kategorie Sachbuch nominiert.

