Name: 26. Januar 1998 
Ort: Frankfurt am Main
Beruf: Content Creator

Younes Zarou wurde am 26. Januar 1998 in Frankfurt am Main geboren. Er ist ein deutscher Webvideoproduzent und Influencer mit marokkanischen Wurzeln. Er wuchs in Flörsheim am Main auf und studierte Wirtschaftsinformatik an der Provadis School of International Management and Technology. 

Im August 2019 begann Zarou, Videos auf der Plattform TikTok hochzuladen. Seine kreativen und actionreichen Inhalte, oft begleitet von Making-of-Videos, fanden schnell großen Anklang. Im März 2020 führte er einen 30-tägigen ununterbrochenen Livestream durch, der zeitweise von bis zu 200.000 Menschen verfolgt wurde. 

Mit über 54 Millionen Followern auf seinem internationalen TikTok-Account (Stand: März 2024) ist er Deutschlands reichweitenstärkster Nutzer der Plattform. 

Im Jahr 2023 nahm er an der 16. Staffel der Tanzshow "Let's Dance" teil und belegte den 11. Platz. Im Mai 2024 unterstützte er Bundeskanzler Olaf Scholz beim Start dessen TikTok-Kanals. 
---
Es ist kein Sprint, sondern ein Marathon.
---
Ich möchte weiter kreativ arbeiten und meine Videos produzieren. Ich will Leute inspirieren und zum Lachen bringen.
---
Ich komme aus einer großen Familie, so bin ich es gewohnt, beobachtet zu werden.
