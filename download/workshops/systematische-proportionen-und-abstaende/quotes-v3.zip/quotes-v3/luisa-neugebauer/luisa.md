Name: Luisa-Marie Neubauer
Ort: Berlin
Beruf: Klimaschutzaktivistin und Publizistin

Luisa-Marie Neubauer, geboren am 21. April 1996 in Hamburg, ist eine prominente deutsche Klimaschutzaktivistin und Publizistin. Sie wuchs als jüngstes von vier Geschwistern im Hamburger Stadtteil Iserbrook auf. Nach dem Abitur 2014 am Marion-Dönhoff-Gymnasium in Hamburg-Blankenese engagierte sie sich in verschiedenen Projekten, darunter Entwicklungshilfe in Tansania und Arbeit auf einem Bio-Bauernhof in England. 2015 begann sie ein Geographiestudium an der Georg-August-Universität Göttingen, das sie 2020 mit einem Bachelor of Science abschloss.

Neubauer ist eine der Hauptorganisatorinnen der "Fridays for Future"-Bewegung in Deutschland, inspiriert von Greta Thunberg. Sie setzt sich für eine Klimapolitik ein, die im Einklang mit dem Pariser Abkommen steht, und fordert einen Kohleausstieg Deutschlands bis 2030. 

Neben ihrem Aktivismus ist sie als Autorin tätig und veröffentlicht regelmäßig Beiträge zu Klimathemen. Sie ist auch als Jugendbotschafterin der Nichtregierungsorganisation ONE aktiv und engagiert sich für verschiedene Umwelt- und Entwicklungsorganisationen. 
---
Verändert das System! Nicht das Klima!
---
Hoffnung ist harte Arbeit. Und mangelnde Hoffnung ist ein Grund zu handeln.
---
Die jungen Leute wissen, worum es geht: Ihre eigene Zukunft ist in Gefahr, wenn der Planet sich ungehindert erhitzt.
---
Fossile Infrastruktur ist selbstverständlich, umweltfreundliche muss sich beweisen.
---
Was für eine unfassbare Belastung ist es für Menschen, die immer mehr über die Klimakrise und die ökologischen Krisen Bescheid wissen?
---
Wandel lässt sich nicht allein mit dem besseren Argument erkämpfen.
---
Wir sind hier, wir sind laut, weil ihr unsere Zukunft klaut.
---
Denn es fühlt sich tatsächlich so an, als würden wir in einem Auto sitzen, das auf einen Abgrund zusteuert. Doch anstatt zu bremsen, wird beschleunigt.


---

