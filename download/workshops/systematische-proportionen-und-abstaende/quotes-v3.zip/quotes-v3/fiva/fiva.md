Name: Nina Sonnenberg a.k.a Fiva
Ort: München
Beruf: Rapperin, Moderatorin und Autorin

Nina Sonnenberg, bekannt als Fiva, wurde am 12. November 1978 in München geboren. Sie ist eine deutsche Rapperin, Moderatorin und Autorin. 2002 veröffentlichte sie ihr Debütalbum "Spiegelschrift" und etablierte sich mit weiteren Alben wie "Die Stadt gehört wieder mir" (2012) und "Nina" (2019). Neben ihrer Musikkarriere ist sie in der Poetry-Slam-Szene aktiv und gewann 2004 mit ihrem Team die deutschsprachigen Slam-Meisterschaften. 

Fiva moderiert seit 2007 für FM4 und war auch im Fernsehen in Sendungen wie "zdf.kulturpalast" präsent. Ihre Texte zeichnen sich durch Einfühlungsvermögen und sprachliche Raffinesse aus, was sie zu einer der markantesten Stimmen im deutschen Rap macht.

---
Ich lass mir das nicht kaputt machen.
---
Ich finde Stille nur schön, wenn sie frei gewählt ist.
---
Es ist einfach großartig, sich seinem Talent hinzugeben!
---
Das Beste ist noch nicht vorbei.
---
Ich bin gar nicht so optimistisch, wie das vielleicht rüberkommt.
---
Ich hab das Gefühl, dass es heute eine größere Offenheit gibt, verschiedene Musikstile zu kombinieren.

---

