Name: Sascha Lobo
Ort: Berlin
Beruf: Autor, Blogger und Internetunternehmer

Sascha Lobo wurde am 11. Mai 1975 in Berlin (West) als Sohn eines Argentiniers und einer Deutschen geboren, die als Archäologin und Kunsthistorikerin arbeitete. L. musste nach eigenen Worten "schon früh ein Übersetzer zwischen den Kulturen sein", was sich später beruflich fortgesetzt habe, "bloß dass ich nicht mehr zwischen Deutschland und Argentinien vermittle, sondern zwischen der analogen und der digitalen Welt" (ZEIT Campus, 6/2013).

L. studierte ab 1995 Publizistik an der Freien Universität Berlin sowie Lebensmittel-, Brauerei- und Biotechnologie an der Technischen Universität. 1998 begann er an der Universität der Künste in Berlin ein Studium der Gesellschafts- und Wirtschaftskommunikation, das er 2013 mit einem Diplom abschloss.


---

„Der richtige Moment lässt viele Dinge im Leben ganz einfach erscheinen.“
― Sascha Lobo

---

“Die veröffentlichte Meinung [...] bildet nur einen kleinen Ausschnitt der öffentlichen Meinung ab.” 
― Sascha Lobo, Wir nennen es Arbeit

---

“Im Internet ist Aufmerksamkeit eine echte Ware geworden, die sich bereits im Moment ihrer Entstehung vermarkten lässt.” 
― Sascha Lobo, Wir nennen es Arbeit

---

“Das Web 2.0 bedeutet vor allem, dass die soziale Reichweite des Einzelnen größer ist als die Reichweite der eigenen Stimme.” 
― Sascha Lobo, Wir nennen es Arbeit

---

“Vorrangiges Ziel der Unternehmen ist nicht in erster Linie Effizienz, sondern Kontrolle.” 
― Sascha Lobo, Wir nennen es Arbeit

“Der feste Beruf auf Lebenszeit [...] ist ein Produkt der Industrialisierung.” 
― Sascha Lobo, Wir nennen es Arbeit