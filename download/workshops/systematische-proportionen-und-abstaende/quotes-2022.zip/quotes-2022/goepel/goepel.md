Name: Prof. Dr. rer. pol. Maja Göpel
Ort: Berlin
Beruf: Generalsekretärin des Wissenschaftlichen Beirats der Bundesregierung Globale Umweltveränderungen

Maja Göpel wurde am 27. Juni 1976 in Bielefeld geboren.

G. legte 1995 in Bielefeld ihr Abitur ab und beendete im Jahr 2001 ihr Studium der Medienwirtschaft an der Universität Siegen mit Diplom. Anschließend forschte sie zum Welthandels-System aus der Sicht der politischen Ökonomie und wurde 2007 an der Gesellschaftswissenschaftlichen Fakultät der Universität Kassel promoviert (Dr. rer. pol.).

Beruflich und wissenschaftlich beschäftigte sich G. frühzeitig mit gesellschaftlichen Aspekten des Themas Nachhaltigkeit und setzte sich dafür ein, politische und soziale Prozesse zur Abwehr des Klimawandels anzustoßen. Ab 2006 war sie für den World Future Council tätig, eine Stiftung, die sich für Nachhaltigkeit und Generationengerechtigkeit engagiert. Sie arbeitete bis 2012 im Hamburger und Brüsseler Büro der Stiftung zu verschiedenen Themen und Kampagnen. Im Febr. 2013 übernahm sie die Leitung des Berliner Büros des Wuppertal Instituts für Klima, Umwelt und Energie, einer privaten Forschungseinrichtung, die sich als Denkfabrik in der Nachhaltigkeitsforschung versteht.

Ab 2017 bekleidete G. den Posten der Generalsekretärin des Wissenschaftlichen Beirats der Bundesregierung Globale Umweltveränderungen (WBGU). 

---

»Als die Apollo 9 zum Mond startete, lag der ökonomische Fußabdruck der Menschheit noch inner-halb dessen, was die Erde hergibt. Seit Mitte der Siebzigerjahre liegt er ständig darüber.« (28

---

»Eine überzeugende absolute Entkopplung des ökonomischen Wachstums einer Volkswirtschaft von ihrem Umweltverbrauch steht weiterhin aus.« (34

--
»Wussten Sie, dass die Hälfte des Kohlendioxids, für das die Menschheit verantwortlich ist, in den vergangenen dreißig Jahren ausgestoßen wurde? Also von uns, unserer Generation. Der Schaden, den wir wissentlich angerichtet haben, ist inzwischen genauso groß wie der, den die Menschheit entstehen ließ, als wir noch nicht wussten, was wir taten.«(

---

»Wenn wir die Welt neu denken wollen, müssen wir zu den gedanklichen Fundamenten zurückge-hen, auf denen die uns heute geläufige Welt aufgebaut ist. Dazu gehört neben dem Blick, den der Mensch auf die Natur hat, auch derBlick, den er auf sich selbst hat.« (56)

---

“Alle Menschen, die ich kenne, wünschen sich Liebe, Frieden, die Überwindung von Armut und eine schöne und sichere Umwelt. Warum also machen wir das dann nicht einfach? Was hält uns als Gesellschaft davon ab?” 

---

Prof. Dr. Maja Göpel, geboren 1976, arbeitet seit 25 Jahren als Politökonomin und Nachhaltigkeitswissenschaftlerin an der Schnittstelle von Wissenschaft, Politik und Gesellschaft. Die gefragte Rednerin wurde 2019 zur Honorarprofessorin der Leuphana Universität Lüneburg berufen und war bis Ende 2020 Generalsekretärin des Wissenschaftlichen Beirats der Bundesregierung Globale Umweltveränderungen (WBGU). Maja Göpel ist Mitglied im Club of Rome, dem World Future Council, der Balaton Group, diverser Beiräte und Aufsichtsräte und Mit-Initiatorin der Initiative »Scientists for Future«. Nachdem ihr Buch Unsere Welt neu denken zum Nr.-1-Bestseller wurde, hat sie sich voll der Wissenschaftskommunikation verschrieben.
Quelle: Verlag / vlb


---

