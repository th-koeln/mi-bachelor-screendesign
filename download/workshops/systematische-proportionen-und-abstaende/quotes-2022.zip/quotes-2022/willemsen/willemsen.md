Name: Dr. phil. Roger Willemsen
Beruf: deutscher Fernsehmoderator und Autor
Geburtstag:	15. August 1955 Bonn
Todestag: 7. Februar 2016 Wentorf bei Hamburg

Roger Willemsen wurde am 15. Aug. 1955 in Bonn geboren und wuchs mit zwei Geschwistern auf. Der 1970 verstorbene Vater war Kunsthistoriker/Restaurator von Beruf, die Mutter Sachverständige für Ostasiatische Kunst. Ein Onkel von W., Prof. Dr. Franz Willemsen, machte sich als Archäologe in Athen einen Namen.

Nach dem Abitur (1976) in Bonn studierte W. Germanistik, Philosophie und Kunstgeschichte in Bonn, Florenz, München und Wien. Seine Doktorarbeit legte er 1984 über die Dichtungstheorie Robert Musils vor. Die Habilitationsarbeit über "Selbstmord in der Literatur" gab er auf. Neben dem Studium war W. mehrere Jahre lang (1977-1981) als Nachtwächter, Reiseleiter und Museumswärter tätig.

W. arbeitete als Assistent für Literaturwissenschaften an der Universität München (1984-1986), als Übersetzer, Herausgeber und freier Autor, ehe er 1988 für drei Jahre nach London ging, wo er als Korrespondent für Zeitungen und Rundfunkstationen tätig war, außerdem übersetzte er u. a. Umberto Eco und Thomas Moore und schrieb Bücher ("Die Abruzzen", "Kopf oder Adler - Ermittlungen gegen Deutschland").

---

„Es ist eine andere Welt, in der man zwischen »Freiheit« und »Freizeit« nicht unterscheiden kann, »Gesellschaft« sagt und »Zielgruppe« meint, von einem »Konzept« spricht und nicht einmal eine »Idee« besitzt, von einer »Idee« spricht und nicht einmal einen Einfall hat.“
― Roger Willemsen

---

„Soziale Fragen löst man, indem man asozialen Fragern den Lebensraum entzieht.“
― Roger Willemsen

---

„Bestimmten Verhältnissen dem Leben gegenüber ist Radikalität das einzig Vernünftige, was Humanität noch rettet.“
― Roger Willemsen

